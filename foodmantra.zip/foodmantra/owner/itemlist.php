<?php

 include "header.php";
 
?>

<div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>ITEM
                                    </div>
                                </div>
                            </div>           
                       
                        <div class="row">
                            
                            <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Income</div>
                                                <div class="widget-subheading">Expected totals</div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-focus">$147</div>
                                            </div>
                                        </div>
                                        <div class="widget-progress-wrapper">
                                            <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                <div class="progress-bar bg-info" role="progressbar" aria-valuenow="54" aria-valuemin="0" aria-valuemax="100" style="width: 54%;"></div>
                                            </div>
                                            <div class="progress-sub-label">
                                                <div class="sub-label-left">Expenses</div>
                                                <div class="sub-label-right">100%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header">ITEMS LIST
                                        
                                    </div>
                                    <div class="table-responsive">
                                   <?php
                                     include "../myclass.php";
                                     $obj1=new myclass("localhost","root","",'foodmantra');
                                      
                                     $k = $obj1->itemlist1($email);
                                     
                                   ?>
                                   <TABLE border="2" class="table" id="itemlist">
                                       <thead>
                                            <tr>
                                                <th>Category Name</th>
                                                <th>Item Name</th>
                                                <th>Item Type</th>
                                                <th>Image</th>
                                                <th>Amount</th>
                                                <th>About</th>
                                                <th></th>
                                            </tr>
                                            <tbody>
                                            <?php
                                            foreach($k as $z)
                                            {
                                            ?>
                                            <tr>
                                                <td><?php echo $z['category_name']; ?></td>
                                                <td><?php echo $z['item_name']; ?></td>
                                                <td><?php echo $z['item_type']; ?></td>
                                                <td> <img src="<?php echo $z['image']; ?>" alt="" height="50px" width="50px"> </td>
                                                <td><?php echo $z['amount']; ?></td>
                                                <td><?php echo $z['about']; ?></td>
                                                <td>
                                                    <a href="delete.php?id=<?php echo $z['id']; ?>&type=itemlist">Delete</a>
                                                </td>
                                            </tr>

                                            <?php
                                            }
                                            ?>
                                            </tbody>

                                        </thead>

                                    </table>
                                </div>
                                   
                                </div>
                            </div>
                        </div>

</div>




<?php

include "footer.php";
?>
<script>
$(document).ready( function () {
    $('#itemlist').DataTable();
} );
</script>