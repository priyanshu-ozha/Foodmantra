<?php
include 'header.php';
include 'connection.php';

$id=$_GET['id'];

$query=mysqli_query($conn,"SELECT * FROM item WHERE id='$id'");

if($id>0)
{
while($k = mysqli_fetch_array($query))
{
    
    
    $category_name = $k['category_name'];  
    $item_name = $k['item_name'];
    $item_type = $k['item_type'];
    $email = $k['email'];
    $image = $k['image'];
    $amount = $k['amount'];
    $about=$k['about'];
    $quantity=1;
    $total=$amount;


}

mysqli_query($conn,"INSERT INTO cart VALUES('$id','$image','$item_name','$amount','$quantity','$total')");

}



?>
  
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg3.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="title text-white">Shop Cart</h3>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <table class="table table-striped table-bordered tbl-shopping-cart">
                  <thead>
                    <tr>
                      <th></th>
                      <th>Photo</th>
                      <th>Product Name</th>
                      <th>Price</th>
                      <th>Quantity</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                <?php
                  $query=mysqli_query($conn,"SELECT * FROM cart ");

 
while($k = mysqli_fetch_array($query))
{
    ?>
                    <tr class="cart_item">
                      <td class="product-remove"><a title="Remove this item" class="remove" href="delete.php?id=<?php echo $k['id']; ?>">×</a></td>
                      
                      <td class="product-thumbnail"><a href="#"><img alt="member" src="owner/<?php echo $k['photo'];     ?>"></a></td>
                      <td class="product-name"><a href="#"><?php echo $k['name']; ?></a>
                        </td>
                      <td class="product-price"><span class="amount"><?php echo $k['price']; ?></span></td>
                      <td class="product-quantity"><div class="quantity buttons_added">
                           
                          <input type="number" size="4" class="input-text qty text" title="Qty" value="1" name="quantity" min="1"  >
                          
                        </div></td>
                      <td class="product-subtotal"><span class="amount"><?php echo $k['total']; ?></span></td>
                    </tr>
                    <?php
}
?>
                    
                    <tr class="cart_item">
                      <td colspan="6"><div class="coupon">
                          <label for="cart-coupon">Coupon: </label>
                          <input id="cart-coupon" type="text" placeholder="Coupon code" value="" name="coupon_code">
                          <button type="button" class="btn">Apply Coupon</button>
                        </div></td>
                      
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
           
                <div class="col-md-6">
                  <h4>Cart Totals</h4>
                  <table class="table table-bordered">
                    <tbody>
                      <tr>
                        <td>Cart Subtotal</td>
                        <?php
                  $query=mysqli_query($conn,"SELECT * FROM cart ");

 
while($k = mysqli_fetch_array($query))
{
    ?>
                        <td><?php $k['total']=$k['total']+$k['total'] ;?></td>
                        <?php
}
?>
                      </tr>
                      <tr>
                        <td>Shipping and Handling</td>
                        <td>$70.00</td>
                      </tr>
                      <tr>
                        <td>Order Total</td>
                        <td>$250.00</td>
                      </tr>
                    </tbody>
                  </table>
                  <a class="btn btn-default">Proceed to Checkout</a> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
  
   