<?php

include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/1.css">
</head>
<body>
<div class="login-page">
<div class="form">
<form class="login-form" action="" method="POST">
      <input type="email" name="email" placeholder="Enter Your Email"/>
      <input type="password" name="password" placeholder="password"/>
      <select name="user_type" id="user_type" requireds>
          <option value="">--USER--</option>
          <option value="admin">Admin</option>
          <option value="owner">Owner</option>
          <option value="customer">Customer</option>
      </select>
      <button>login</button>
      <p class="message">Not registered? <a href="#">Create an account</a></p>
    </form>
  </div>
</div>
</div>
</body>
</html>
<?php
if($_POST)
{ 
  $email=htmlspecialchars($_POST['email']);
  $password=htmlspecialchars($_POST['password']);
  $user_type=htmlspecialchars($_POST['user_type']);
  // include "myclass.php";
  // $obj=new myclass("localhost","root","","foodmantra");
  $checkemail=filter_var($email,FILTER_VALIDATE_EMAIL);
  if ($checkemail)
  {
    session_start();
   
    if($user_type=="admin"){
      $query = mysqli_query($conn,"SELECT * FROM users WHERE email='$email' and pass='$password'");
      if (mysqli_num_rows($query)==0)
      {
        echo "<script> alert('Invalid Credentials'); </script>";
      }
      else{

        $_SESSION['mysession']=$email;
        
        header("location:admin/index.php");
      }
    }
    else if ($user_type=="owner") {
      $query = mysqli_query($conn,"SELECT * FROM users WHERE email='$email' and pass='$password'");
      if (mysqli_num_rows($query)==0)
      {
        echo "<script> alert('Invalid Credentials'); </script>";
      }
      else{
        
        $_SESSION['mysession']=$email;
        

        
        header("location:owner/index.php");
      }
      
    }else{
      $query=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' and password='$password'");
      if (mysqli_num_rows($query)==0)
      {
        echo "<script> alert('Invalid Credentials'); </script>";
      }

      else{
        

        $_SESSION['mysession']=$email;
        header("location:customer/index.php");
      }
    }

    
  }

}

?>