<?php

ob_start();
include "header.php";

include "connection.php";

$id = $_GET['id'];





$query=mysqli_query($conn,"SELECT * FROM item WHERE id='$id'");

 
while($k = mysqli_fetch_array($query))
{
    
    
    $category_name = $k['category_name'];  
    $item_name = $k['item_name'];
    $item_type = $k['item_type'];
    $oemail = $k['email'];
    $image = $k['image'];
    $amount = $k['amount'];
    $about=$k['about'];


}
?>
 

  
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg3.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="title text-white text-center"><?php echo $item_name; ?></h2>
              
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="product">
              <div class="col-md-5">
                <div class="product-image">
                  <div class="zoom-gallery">
                    <a href="owner/<?php echo $image;?>" title="Title Here 1"><img src="owner/<?php echo $image;?>" alt=""></a>
                  </div>
                </div>
              </div>
              <div class="col-md-7">
                <div class="product-summary">
                  <h2 class="product-title"><?php echo $item_name; ?></h2>
                  
                  <form  action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                  <input name="itemname" class="form-control" type="text" required="" value="<?php echo $item_name; ?>">
                </div>

                <div class="form-group">
                  <input name="categoryname" class="form-control" type="text" required="" value="<?php echo $category_name; ?>">
                </div>

                <div class="form-group">
                  <input name="amount" class="form-control" type="text" required="" value="<?php echo $amount; ?>">
                </div>

                <div class="form-group">
                  <input name="date" class="form-control" type="date" required="" >
                </div>

                <div class="form-group">
                    <select name="payment_mode" id="" class="form-control">
                        <option value="">---SELECT PAYMENT MODE---</option>
                        <option value="online">Online</option>
                        <option value="offline">Offline</option>
                    </select>
                </div>
                 
                 <button class="single_add_to_cart_button btn btn-theme-colored" type="submit">Buy Now</button>
                    </form>
                  </div>
                </div>
              </div>
               
              </div>
            </div>
              
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  <?php

  if($_POST)
  {
      extract($_POST);
    
      if($payment_mode=='offline')
      {
          mysqli_query($conn,"INSERT into orders Values('','$item_name','$category_name','$amount','$oemail','$email','$date')");
          echo "<script>alert('Purchase Sucessful');</script>";
          header('location:index.php');
      }
      else
      {
        $_SESSION['name']=$category_name;
        $_SESSION['amount']=$amount;
          header('location:payment.php');
      }
  }

 include "footer.php";
?>
 