<?php
include "header.php";
include "connection.php";
?>

  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">REGISTER NOW</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-push-2">
            <div class="widget border-1px p-30">
              <h5 class="widget-title line-bottom">Register Now</h5>
              <form  action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                  <input name="myname" class="form-control" type="text" required="" placeholder="Enter Name">
                </div>
              <div class="form-group">
                  <input name="phone" class="form-control" type="text" required="" placeholder="Enter Phone">
                </div>
              <div class="form-group">
                  <input name="email" class="form-control" type="email" required="" placeholder="Enter Email">
                </div>

                <div class="form-group">
                  <input name="pass" class="form-control" type="password" required="" placeholder="Enter Password">
                </div>
                <div class="form-group">
                 <select name="state" class="form-control">
                   <option>--State--</option>
                   <option value="up">Uttar Pradesh</option>
                   <option value="mumbai">Mumbai</option>
                 </select>
                </div>
                <div class="form-group">
                 <select name="city" class="form-control">
                   <option>--City--</option>
                   <option value="ayodhya">Ayodhya</option>
                   <option value="lko">Lucknow</option>
                 </select>
                </div>
                <div class="form-group">
                  <input name="pin" class="form-control" type="text" required="" placeholder="Enter Pin">
                </div>
                <div class="form-group">
                  <textarea name="address" id="" cols="30" rows="1"  class="form-control" placeholder="Address"></textarea>
                </div>
                <div class="form-group">
                <input name="file" class="form-control" type="file" required="" placeholder="Enter Pin">
                </div>
                

                
                <div class="form-group">
                  <input type="submit" class="btn btn-primary"   class="form-control"   required="" value="Register">
                </div>
                
              </form>

              
            </div>
          </div>
        </div>
      </div>
    </section> 
  </div>  


<?php
if($_POST){
    extract($_POST);
   
    
    $tmp = $_FILES['file']['tmp_name'];
    $name = $_FILES['file']['name'];
    $folder = "owner/folder/itemimg/";

   $merge = $folder.$name;
   move_uploaded_file($tmp,$merge);
  
   $checkname=preg_match("/^[a-zA-Z]{3,30}$/",$myname);
  $checkphone=preg_match("/^[0-9]{10,10}$/",$phone);
  $checkpin=preg_match("/^[0-9]{6,6}$/",$pin);
  $checkemail=filter_var($email,FILTER_VALIDATE_EMAIL);

  if($checkname && $checkphone)
  {
    $query = mysqli_query($conn,"SELECT * FROM customer where email='$email'");
    if(mysqli_num_rows($query)==1){
        echo "<script>alert('Already Registered')</script>"; 
    }
    else{
    mysqli_query($conn,"INSERT INTO customer VALUES('','$myname','$phone','$email','$pass','$state','$city','$pin','$address','$merge');");
    echo "<script>alert('Successfully Registered')</script>";
    echo("<script>location.href ='login1.php';</script>");
    }
  } 
  
  else{
    echo "<script>alert('Error! Validation Failed')</script>";
  }
  

}

?>
<?php
include "footer.php";
?>