<?php
session_start();
$email=$_SESSION['session'];
session_destroy();
header("location:login1.php");
?>