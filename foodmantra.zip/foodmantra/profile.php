 <?php
 
include 'header.php';
include 'connection.php';

 



$query=mysqli_query($conn,"SELECT * from customer where email='$email' ");

while($k = mysqli_fetch_array($query))
{
    
    
  
    $name = $k['name'];
    $phone = $k['phone'];
    $email = $k['email'];
    $state = $k['state'];
    $city=$k['city'];
    $pin=$k['pin'];
    $address=$k['address'];
    $photo=$k['photo'];


}

?>
 

  
  <!-- Start main-content -->
  <div class="main-content bg-lighter">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="title text-white text-center">Profile</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Experts Details -->
    <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-4">
              <div class="thumb">
                <img src="<?php echo $photo;?>" style="border-radius:50%;" height="250px" width="250px" alt="">
              </div>
            </div>
            <div class="col-md-8">
              <h4 class="name font-24 mt-0 mb-0"><?php echo $name;   ?></h4>
             
              <br><br>
              <table class="table">
  <thead>
     
  </thead>
  <tbody>
    <tr>
      <th scope="row">Phone</th>
      <td><?php echo $phone;   ?></td>
      
    </tr>
    <tr>
      <th scope="row">Email</th>
      <td><?php echo $email;   ?></td>
      
    </tr>
    <tr>
      <th scope="row">State</th>
      <td><?php echo $state;   ?></td>
      
    </tr>
    <tr>
      <th scope="row">City</th>
      <td><?php echo $city;   ?></td>
      
    </tr>
    <tr>
      <th scope="row">Pin</th>
      <td><?php echo $pin;   ?></td>
      
    </tr>
    <tr>
      <th scope="row">Address</th>
      <td><?php echo $address;   ?></td>
      
    </tr>
  </tbody>
 
</table>
<a href="updateprofile.php" class="btn btn-primary">Update Profile</a>
                        
 <a href="change_password.php" class="btn btn-danger">Change Password</a>
             
            </div>
          </div>
          <div class="row mt-30">
            <div class="col-md-4">
              <h4 class="line-bottom">About Me:</h4>
              <div class="volunteer-address">
                <ul>
                <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="orders.php">My Orders</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="updateprofile.php">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout1.php">Signout</a>
                      </div>
                    </div>
                  </li>
                  
             
            
            
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->

  <?php
include 'footer.php';

?>
  
  