<?php
include "header.php";
include "connection.php";

$p=mysqli_query($conn,"SELECT * FROM customer WHERE email='$email'");
while($z=mysqli_fetch_array($p)){
    $name=$z['name'];
    $phone=$z['phone'];
    $state=$z['state'];
    $city=$z['city'];
    $pin=$z['pin'];
    $address=$z['address'];
    $photo=$z['photo'];
}
?>

 <!-- Start main-content -->
 <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">UPDATE PROFILE</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-push-2">
            <div class="widget border-1px p-30">
              <h5 class="widget-title line-bottom">Update Profile</h5>
              <form  action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                  <input name="myname" class="form-control" type="text" value="<?php echo $name;?>">
                </div>
              <div class="form-group">
                  <input name="phone" class="form-control" type="text" value="<?php echo $phone;?>">
                </div>
                <div class="form-group">
                 <select name="state" class="form-control">
                   <option>--State--</option>
                   <option value="up">Uttar Pradesh</option>
                   <option value="mumbai">Mumbai</option>
                 </select>
                </div>
                <div class="form-group">
                 <select name="city" class="form-control">
                   <option>--City--</option>
                   <option value="ayodhya">Ayodhya</option>
                   <option value="lko">Lucknow</option>
                 </select>
                </div>
                <div class="form-group">
                  <input name="pin" class="form-control" type="text" value="<?php echo $pin;?>">
                </div>
                <div class="form-group">
                  <textarea name="address" id="" cols="30" rows="1"  class="form-control"><?php echo $address;?></textarea>
                </div>
                <div class="form-group">
                <input name="file" class="form-control" type="file" value="<?php echo $photo;?>">
                </div>
                

                
                <div class="form-group">
                  <input type="submit" class="btn btn-primary"   class="form-control"   required="" value="Register">
                </div>
                
              </form>

              
            </div>
          </div>
        </div>
      </div>
    </section> 
  </div>  

  <?php
 if($_POST){
     extract($_POST);
    $tmp = $_FILES['file']['tmp_name'];
    $name = $_FILES['file']['name'];
    $folder = "owner/folder/itemimg/";

   $merge = $folder.$name;
   move_uploaded_file($tmp,$merge);
  
   mysqli_query($conn, " UPDATE customer
      SET name = '$myname',
      phone='$phone',
      state='$state',
      city='$city',
      pin='$pin',
      address='$address',
      photo='$merge' where email='$email'");

    
  echo "<script>alert('Profile Updated Successfully!!');</script>";
  echo "<script>window.location.href='profile.php';</script>";

 }

?>



























<?php
include "footer.php";
?>