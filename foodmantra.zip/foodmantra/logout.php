<?php
session_start();
$email=$_SESSION['mysession'];
session_destroy();
header("location:login.php");
?>