<?php
include "header.php";
include "connection.php";
$id=$_GET['id'];
$p=mysqli_query($conn,"SELECT * FROM categories WHERE id='$id'");
while($x=mysqli_fetch_array($p)){
    $category_name=$x['category_name'];
}



?>



<!-- Start main-content -->


    <section>
      <div class="container pb-0">
         
       
        <div class="row multi-row-clearfix">
          <div class="col-md-12">
           <div class="products">
           <?php
          
                 $query=mysqli_query($conn,"SELECT * FROM item where category_name='$category_name' ");
                 while($k=mysqli_fetch_array($query))
                 {
                ?>
              <div class="col-sm-6 col-md-4 col-lg-3 mb-30">
             
                <div class="product">
               
                  <span class="tag-sale">Sale!</span>
                  <div class="product-thumb"> 
                    <img alt="" src="owner/<?php echo $k['image'];?>" class="img-responsive img-fullwidth">
                  </div>
                  <div class="product-details text-center">
                    <a href="productdetails.php?id=<?php echo $k['id'];?>"><h5 class="product-title"><?php echo $k['item_name']; ?></h5></a>
                    <div class="star-rating" title="Rated 3.50 out of 5"><span style="width: 67%;">3.50</span></div>
                    <div class="price"><del><span class="amount"><?php echo $k['amount']; ?></span></del><ins><span class="amount">$90.00</span></ins></div>
                  </div>
                </div>
                
              </div>
              <?php
                 }
                ?>
 
            </div>
          </div>
        </div>
      </div>
    </section>

    

    <!-- Section: Shop  -->
   













<?php
include "footer.php";
?>