<?php
include "../connection.php";
session_start();
$hemail=$_SESSION['hotelemaildelete'];
?>
<?php
$id = $_GET['id'];
$type=$_GET['type'];

if($type=='category')
{

mysqli_query($conn,"DELETE FROM categories WHERE id='$id'");
header("location:categorylist.php");
}
else if($type=='course')
{
  
    mysqli_query($conn,"DELETE FROM courses WHERE id='$id'");
    header("location:courselist.php");
}
else if($type=='itemlist')
{
    mysqli_query($conn,"DELETE FROM item WHERE id='$id'");
    header("location:itemlist.php");
}
else if($type=='orderlist'){
    mysqli_query($conn,"DELETE FROM orders WHERE id='$id'");
    header("location:orderlist.php");
}
else if($type=='customerlist')
{
  
    mysqli_query($conn,"DELETE FROM customer WHERE id='$id'");
    header("location:courselist.php");
}
else if($type=='hotellist')
{
  
    mysqli_query($conn,"DELETE FROM hotelregister1 WHERE email='$hemail'");
    mysqli_query($conn,"DELETE FROM hotelregister2 WHERE email='$hemail'");
    header("location:courselist.php");
}
?>